# Revisão 2 — alterações e rastreabilidade

Substitui integralmente a revisão anterior, sem exigir consulta a adendas. Preparado por revisão estática dos ZIPs identificados no manifesto. Não altera código do AISA.

## Tratamento dos achados adversariais

| Achado | Correção | Prova exigida |
|---|---|---|
| 1. Autoridade ambígua | Contrato A e P1; autoridades existentes preservadas | K05, L01–L10, C08 |
| 2. Escritas parciais/concorrência | Contrato B e P2 | W01–W08 |
| 3. Continuidade declarada cedo | P3 técnico, P4 operação completa, P8 prova total | B01–B07, L01–L05, E01–E02 |
| 4. Migração incompleta | Contrato C e P5 | M01–M06 |
| 5. Coverage desatualizada | Dependências consumidas/fingerprints; sem flags | C01–C08 |
| 6. Bootstrap só em texto | Entradas reais, subprocessos e snapshots | B01–B07, U05 |
| 7. Contexto omite premissas | Regras de parcialidade/proveniência e gate completo | B05–B07 |
| 8. Pilotos autorreferenciais | Oráculos independentes e três dimensões de qualidade | E01–E05 |
| 9. Loop sem saída/testes rígidos | Classificação de falhas e mudanças legítimas de contrato | Relatório e política de baseline |
| 10. Cortes antes da prova | P8 precede P9; council opcional P11 | S01–S04 e repetição de pilotos |

## Correspondência de âmbito com o plano anterior

| Fases anteriores | Destino nesta revisão |
|---|---|
| 0 baseline | P0 |
| 1 capacidades | P1 + matriz de capacidades |
| 2 higiene/arquivo | P9/P10; inventário em P0 |
| 3 grafo | P2, com recuperação antes da integração |
| 4 bootstrap | P3 técnico + P4/E2E posterior |
| 5 Discovery/Capture | P4 + P6 |
| 6 Unknowns/Findings/contradições/assumptions | P4/P6, com estados reais do kernel |
| 7 coerência SU/grafo | Contrato A desde P1; enforcement P4/P6 |
| 8 Coverage | Contrato C; integração inicial P4 e completa P6 |
| 9 projeções | P7 |
| 10 UX início/fim | P3/P4/P7 |
| 11 memórias concorrentes | P9 |
| 12 narrativa/dashboard | P9 |
| 13 hooks | P9 |
| 14 council | P11 opcional |
| 15 continuidade completa | P8, antes dos cortes |
| 16 pilotos reais | P1 referência + P8 validação |
| 17 hardening | P10 |

Adições explícitas: migração/reversão, commit observável entre artefactos, proteção de leitores, isolamento, retries, corrupção versus deriva, compatibilidade e oráculos. Corrigida identificação do doador para `ai-solution-architect-main 2(2).zip`. Retirada afirmação incondicional `implementation-ready`.

## Limites

Os oráculos não vêm preenchidos porque este pacote não analisou o conteúdo de pilotos como fonte de verdade de negócio. Os ZIPs de código não são duplicados dentro desta entrega; devem ser disponibilizados ao executor conforme README. A fase P0 mede o baseline real. Este pacote não requer pesquisa externa para validar os factos estáveis dos anexos.
