# Prompt para executar no Claude Code

Implementa o pacote AISA Evolution Plan revisão 2 no repositório alvo AISA RT Fix. O AI Solution Architect anexado é apenas doador de arquitetura. O utilizador quer preservar a experiência e metodologia AISA, acrescentar memória entre sessões e simplificar apenas com evidência.

Lê README.md, IMPLEMENTATION_PLAN.md, todos os contratos e validation/ACCEPTANCE.md deste pacote, e as instruções aplicáveis do repositório. Confirma os inputs pelo SOURCE_MANIFEST.json; se usares um checkout diferente, regista identidade/diff e avalia impacto antes de reutilizar conclusões. Não sobreponhas o doador ao alvo.

Executa P0–P10 sequencialmente. Começa por baseline e contratos; não saltes para portar código. Usa o mínimo de mecanismos coerentes com o kernel. Não introduzas estados concorrentes, filas persistentes, serviços ou dependências Node só porque existem no doador.

Preserva as autoridades, histórico append-only, `was`/`resolved`, regras Confirmed/Assumed, respostas literais, decisões e fact ≠ fit. O grafo é persistência de relações e projeção rastreável. Implementa primeiro recuperação/concorrência e bootstrap técnico; depois uma operação Capture/answer completa entre sessões; depois migração e integração restante. Pilotos completos precedem cortes.

Para cada fase:
1. Regista objetivo, contratos, precondições, ficheiros e testes antes de alterar.
2. Implementa a alteração mínima e os casos de validation/cases.json correspondentes.
3. Executa testes direcionados, de subsistema e regressão completa nos runners descobertos.
4. Corrige regressões sem apagar/saltar/enfraquecer garantias; alterações legítimas de contrato exigem mapa de substituição.
5. Preenche docs/evolution/Pn-report.md usando o template e decide GO/NO-GO com evidência.
6. Se GO, continua à fase seguinte sem pedir confirmação rotineira. Dá atualizações regulares com descobertas, resultado e próximo passo.

Distingue falha introduzida, baseline, ambiente, falta de entrada e decisão de produto. Duas tentativas sem evidência nova sobre a mesma falha exigem diagnóstico, não um ciclo cego. Continua tarefas independentes possíveis, mas não atravesses um gate bloqueado. Não declares sucesso parcial como entrega completa.

Pede intervenção apenas para ambiguidade real de produto não resolvida pelos contratos, inputs/acesso indispensáveis ou mudança metodológica não autorizada. Explica a decisão e a evidência específica que falta. Não repitas pedidos já respondidos pelo utilizador.

P11 é opcional, fora da entrega obrigatória. Mantém o council atual se não houver evidência suficiente para a experiência ou se qualidade for inconclusiva. Não deixes esta otimização impedir a conclusão P0–P10.

Termina apenas com as condições obrigatórias demonstradas, documentação de uso/migração/recuperação e FINAL-VALIDATION.md, ou com um bloqueio externo concreto e reportado. Não inventes resultados de sessões, oráculos, timestamps de execução ou contagens. O utilizador deve conseguir retomar de onde paraste pelos relatórios e artefactos reais.
