# Contrato C — Migração, fontes e Coverage

## C1. Migração legacy → memória persistente

1. Inventariar fontes e artefactos com hashes, leitores e versão do runtime; fixar snapshot sem escritores concorrentes.
2. Dry-run: ler SU, respostas, decisões, state, captura, findings e outputs existentes. Produzir tabela origem → ID/representação destino, campos preservados, ligações recuperadas e exceções.
3. Classificar cada item: projetável sem ambiguidade, já representado, ambíguo, inválido ou não suportado. Não resolver contradições por recência ou ordenar decisões sem referência explícita.
4. Guardar backup verificável dos ficheiros tocados e versão do runtime. Não depender apenas de git para engagements ignorados/untracked. Confirmar espaço e leitura do backup.
5. Aplicar pelo coordenador; preservar IDs, anchors, `was`, `resolved`, respostas literais, autores/datas, autoridade e evidência. Relações inferidas ficam explicitamente inferidas.
6. Comparar antes/depois: conhecimento ativo, cadeia de resoluções, decisões, fase, Coverage e bloqueios. Alteração de embalagem/ordem não deve alterar semântica.
7. Publicar relatório e revisão migrada. Repetir migração com mesmas entradas é no-op sem nós duplicados nem nova aprovação/revisão metodológica.

Dry-run não escreve no engagement; relatório fica em local externo ao snapshot. Entrada mudou após dry-run: rejeitar plano antigo e recalcular. Migração parcialmente aplicada recupera pelo protocolo B.

Migração que não preserva campo material não declara sucesso total. Pode publicar relatório e contexto limitado, mas bloqueia o avanço afetado. Campo estrutural desconhecido preservado no backup não conta como conhecimento corretamente migrado.

## C2. Reversão

Antes de aceitar migração, provar restore de cópia e igualdade de hashes dos artefactos originais, removendo apenas ficheiros novos identificados no manifesto da migração. Não remover ficheiros do utilizador desconhecidos.

Reversão automática só sobre a mesma revisão pós-migração e sem alterações posteriores. Se houve trabalho novo, recusar restore cego; preservar snapshot atual e preparar exportação/reconciliação desse trabalho antes de qualquer reversão. A documentação deve explicar limites de downgrade.

## C3. Fontes e proveniência

A mesma fonte lógica tem ID estável e versões com hash dos bytes. Fonte repetida sem alteração não duplica evidência. Conteúdo igual noutro contexto não é automaticamente a mesma fonte. Captura guarda versão de origem, método/versão de extração e locator.

Atualização preserva a versão anterior e regista sucessão; não reatribui um locator histórico aos bytes novos. Folha renomeada, linhas deslocadas ou fórmula mudada exige resolver pela versão/identidade; não assumir que a mesma coordenada significa o mesmo facto.

Extração sem capacidade de ler VBA, ligações externas, fórmulas sem resultado calculado ou objetos não suportados deve declarar limite e Unknown quando material; não executar macros como parte desta migração nem inventar comportamento. O porte de persistência não promete reparar automaticamente lacunas do extrator.

Afirmações afetadas são identificadas por referências/dependências, preservando contexto histórico. Detectar mudança não prova que a conclusão anterior ficou falsa. Reavaliar conteúdo e aplicar transições existentes, sem reescrever a história.

## C4. Coverage: integração mínima

Reutilizar `coverage.py` e leitores/fingerprints do contrato atual. SU e decisões são `informative` no manifesto mas participam por fingerprint semântico. Não adicionar `coverage_valid`, `coverage_stale` ou percentagens de grafo em state.

Estratégia por defeito: todo claim/regra/estado material consumido por Coverage mantém autoridade SU/decisions/capture já coberta. Relações novas no grafo podem servir navegação sem mudar a base Coverage. Se uma relação exclusivamente no grafo passar a sustentar a avaliação, acrescentar ao contrato uma dependência explícita e fingerprint canónico do subconjunto efetivamente consumido. P1/P6 listam campos, ordenação, algoritmo e testes. Não invalidar pela versão global do grafo indiscriminadamente.

Mudança de formato técnico de uma base exige versionar schema e tratamento de revisões antigas (p.ex. não verificável/requer nova revisão), nunca marcar automaticamente válida. Mudança de suficiência, denominador, política de pressupostos ou aprovação é decisão metodológica, não detalhe de adaptador.

| Evento | Resultado esperado |
|---|---|
| Nova sessão sem alteração | Mesmos fingerprints, mesma atualidade |
| Reordenação de nós/arestas/JSON sem alteração semântica | Não torna stale por essa razão |
| Mudança de claim material SU | Atualidade segundo fingerprint existente; explicar delta |
| Resolução via pressuposto | Mantém Assumed; não equivale a evidência confirmada |
| Nova resposta literal | Motor determina impacto pelas fontes/fingerprints existentes |
| Relação de navegação não consumida pela revisão | Não altera a base só por existir |
| Alteração de dependência de grafo consumida | Altera fingerprint da dependência; revisão anterior requer reavaliação |
| Fonte atualizada/locator deixou de resolver | Identificar âmbito afetado e falta de verificação; não apagar história |
| Aprovação de Blueprint | Manter exclusões específicas já previstas para não invalidar a própria revisão |
| Alteração meramente narrativa SU | Reutilizar normalização existente; testar que não há mudança material oculta |
| Fonte ilegível/check não executado | Nunca apresentar avaliação limpa como se tivesse sido realizada |
| Recuperação pendente/espelho divergente | Não consumir revisão para avanço até snapshot consistente |

`stale` significa que a base mudou e precisa de revisão, não que a conclusão é falsa. Resolver um Unknown não finaliza Coverage nem aprova Blueprint automaticamente. Contradição não escolhe um lado; N/A/retirada requer base conforme metodologia. Comparar as três etapas relevantes: reconciliation, blueprint e render.
