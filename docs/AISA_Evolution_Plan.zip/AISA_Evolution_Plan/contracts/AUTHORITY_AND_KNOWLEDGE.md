# Contrato A — Autoridade e conhecimento

Normativo para P1–P10. Decisão: preservar as autoridades semânticas existentes; grafo como relações persistentes e projeção rastreável, não substituto da SU.

## A1. Matriz de autoridade

| Informação/campo | Autoridade | Grafo e consumidores | Escrita permitida |
|---|---|---|---|
| Bytes de fonte original | Fonte versionada no engagement | Referência, hash, locator | Intake/update de fonte; nunca sobrescrever a versão histórica silenciosamente |
| Identidade e versão da fonte | Manifesto existente se houver; caso contrário metadados Evidence no grafo | Uma autoridade selecionada em P1, nunca dois manifestos independentes | Adaptador de captura |
| Resultado de extração | Artefacto `_capture/` com método e hash da fonte | Referência a dados medidos | Extrator; nunca inferência disfarçada de medição |
| Claim, texto e estado epistemológico | Linha SU | Nó espelhado com origem e revisão | Operação AISA que cumpre `states.md` |
| Regra de negócio material | Linha SU com evidência/basis | BusinessRule referencia a linha; texto/estado não editáveis no grafo | Discovery/answer segundo regras existentes |
| Unknown: pergunta, criticidade, estado e resolução | SU, incluindo sucessores e markers | Projeção de item aberto/resolvido | Answer/retirada/revalidação autorizada |
| Assumed, Conflicted e Risky | SU | Projeção, nunca enum concorrente | Transições existentes |
| Resposta literal e autor/data | `answers.md` (ou artefacto de intake já autorizado) | Locator, sem reescrita da resposta | Captura de declaração literal |
| Autoridade humana e âmbito | Registo existente em `enquadramento.md`/intake | Referência verificável | Declaração autorizada; não inferir cargo/autoridade |
| Decisão e substituição | `decisions.md` | Nó de referência com estado derivado | Decide/revisit; answer não reescreve decisão |
| Fase e pacote ativo | `_state.json` | Projeção | Transição de fase validada |
| Findings | Artefacto autoritativo existente identificado em P1 | Espelho ou referência | Operação que já cria/dispõe Finding |
| Relações adicionais e proveniência | Grafo, apenas quando não codificadas por autoridade anterior | Tipadas e verificáveis | Adaptador de conhecimento |
| Relação `was`/`resolved`/supersession existente | Artefacto onde a relação é declarada | Aresta projetada, não editável isoladamente | Transição original |
| Revisão Coverage | Registos `_coverage/` sob contrato atual | Estado calculado | Motor/fluxo autorizado de revisão; não graph-add |
| Estado atual Coverage/gate/fila/next | Cálculo sobre autoridades verificadas | Não persistir verdade independente | Sem setter de verdade |
| Blueprint/Render e aprovações | Artefactos versionados e decisões sob contratos atuais | Referências/dependências | Comandos existentes e controlo de aprovação |
| Síntese narrativa SU | Secções de narrativa SU | Contexto complementar | Edição metodológica, sem contradizer linhas estruturadas |
| Diary/retro universal | Conhecimento estático curado, se mantido | Não fonte de factos de projeto | Sem promoção automática de memória privada |

P1 deve concretizar a linha Findings e a identidade de fonte com base no código real. Se Findings não tiver armazenamento distinto, escolher uma representação que preserve os campos existentes; não criar um segundo lifecycle. Esta escolha de localização é de implementação, não autorização para apagar distinções.

## A2. Esquema mínimo e identidade

Suportar Evidence, Claim, BusinessRule, Unknown e referências Decision onde úteis. Representar estados AISA como estado do conhecimento espelhado; uma resolução não é uma promoção em lugar do histórico. Findings podem ser projeções de artefactos existentes; introduzir tipo próprio apenas se a distinção exige campos não representáveis sem perda.

Cada nó espelhado identifica engagement, ID estável, autoridade (`file`, anchor/ID), revisão semântica de origem e campos derivados. IDs do grafo devem ser estáveis e associados aos IDs AISA; não renumerar linhas SU. Separar ID de fonte de versão/hash. Não deduplicar por texto apenas: duas fontes ou âmbitos diferentes podem dizer a mesma frase sem serem a mesma evidência.

Arestas mínimas: supported_by, derived_from, contradicts, supersedes, resolves e referência contextual quando justificada. Definir domínio/destino permitido de cada relação em P1. Não inventar links; ausência de ligação é informação a avaliar, não defeito estético. `blocks` só se baseado numa regra/gate existente, com referência à razão; não booleano livre que substitui o motor.

Toda relação nova material deve preservar basis/origem e, quando inferida, essa classificação. Igualdade lexical, proximidade num ficheiro ou recência não são prova de causalidade.

## A3. Estados e transições

Não substituir os cinco estados de `states.md` por OPEN/IN_PROGRESS/RESOLVED. Aberto/resolvido é projeção do histórico e markers existentes. Não acrescentar enum independente se o lifecycle já é representável.

Exemplo obrigatório: `U-007` permanece na SU; resposta literal em `answers.md`; nova `A-012 was U-007` se inferência; origem marcada `resolved → A-012`. Grafo referencia ambos e representa a transição. Nova sessão vê Unknown resolvido e pressuposto ativo, nunca um facto confirmado nem uma pergunta novamente aberta.

Confirmed exige locator resolúvel e claim ao nível da evidência; uma fórmula prova o que o ficheiro calcula, não que a empresa adotou essa regra. Reproduzir regras de autoridade, validade, expiração, correção por evidência, retirada por âmbito e revalidação do kernel. Não reinterpretar risk acceptance/N/A como prova. Uma confirmação de capacidade não fecha automaticamente adequação arquitetural.

Os checks determinísticos verificam estrutura, existência e relações; não certificam verdade semântica. Julgamento semântico continua na metodologia/lenses e no oráculo de aceitação.

## A4. Coerência e edições externas

Campos espelhados diferentes da autoridade são DRIFT, nunca resolvidos por last-write-wins. Grafo alterado à mão não ganha precedência sobre SU. SU alterada por via suportada deve passar pelo coordenador. Edição externa deve ser detetada pela revisão/digest de entradas antes da leitura operacional e antes do commit.

Reprojeção determinística é permitida para campos derivados após validar autoridade; registar operação. Se alteração implica interpretação (p.ex. nova prosa sem ID, dois estados incompatíveis), declarar conflito e bloquear só as ações dependentes. Não deixar uma reparação técnica promover factos.

Narrativa pode condensar; não pode ser usada para autorizar gate contra o estado estruturado. Conhecimento material presente só na narrativa deve ser normalizado para linha/referência antes de sustentar decisão. Não exigir equivalência formal palavra a palavra.

## A5. Controle de expansão

Sem base de dados de tarefas nova, sem stores por agente, sem duplicação do conteúdo bruto das fontes. Ficheiros de recuperação e relatórios de implementação não são fontes metodológicas. Reutilizar leitores SU e de decisões existentes em vez de criar parsers incompatíveis. Contar stores de verdade, artefactos obrigatórios, comandos, hooks e LOC, distinguindo espelhos reconstruíveis de informação única.
