# Validação e critérios de aceitação

## 1. O que este pacote prova

Os documentos e o inventário `cases.json` especificam testes a implementar. Não constituem testes executados. A preparação deste ZIP valida integridade, referências e coerência documental; a regressão do AISA pertence à execução P0–P10.

Cada caso tem ID estável, fase, ação adversarial e resultado esperado. O Claude deve ligá-lo a teste automatizado, cenário de sessão ou revisão documentada. Não basta criar um ficheiro com o mesmo nome ou imprimir PASS. Guardar comando, ambiente, saída, assertivas e artefactos antes/depois. Um teste de estrutura de prompts é insuficiente para provar comportamento de runtime.

## 2. Critérios objetivos

Para a entrega obrigatória:

- Zero perda de IDs, estados, resoluções, decisões e proveniência material nos casos controlados.
- Zero factos confirmados indevidamente nos itens críticos dos oráculos; inferência com basis permanece Assumed.
- Zero avanço indevido nos cenários de bloqueio, snapshot parcial, conflito relevante ou dependência material não verificada.
- Zero sucesso falso de operação interrompida/rejeitada.
- Zero duplicação de efeitos em retries e migração repetida.
- Todos os casos obrigatórios ligados a evidência. N/A exige precondição realmente ausente e justificação; não serve para evitar testar a funcionalidade implementada.
- Nenhuma regressão nova inexplicada. Falhas baseline admitidas apenas conforme política abaixo.
- Continuidade do agente provada em sessões Claude Code independentes; subprocessos comprovam storage mas não a recuperação de raciocínio do agente.

## 3. Baseline e alterações de testes

Inventariar runners, arquivos e IDs. Comparar testes por identidade e comportamento protegido. Contagens agregadas são auxiliares: eliminar um teste e adicionar outro pode esconder perda de garantia.

Falha pré-existente: guardar reprodução no baseline, assinatura, âmbito e impacto. Não pode ser usada para esconder novo erro com o mesmo nome. Se impede validar a alteração, corrigir em mudança separada ou bloquear. Skip/xfail baseline tem de continuar visível; skip novo não é aceite sem causa e garantia alternativa válida. Collection error ou timeout é resultado incompleto, não suite verde.

Mudança intencional de contrato: registar requisito antigo/novo, autorização neste plano, teste alterado e teste substituto que preserva a garantia relevante. Exemplo legítimo: ausência de `story.md` deixa de bloquear, mas ausência de decisão/evidência continua a bloquear quando exigida. Não alterar valores esperados para acomodar uma regressão.

Limites de execução: fixar timeout por runner após medir P0, com margem declarada. Quando excedido, guardar diagnóstico/processos/logs e parar a execução pendurada. Não repetir indefinidamente. Após duas tentativas sem evidência nova, classificar a causa e reportar o bloqueio; não aprovar a fase por esgotamento de tentativas.

## 4. Injeção de falhas

Testar operação real e store isolado. Encerrar processo em pontos antes/depois da intenção, após cada publicação individual, antes/depois do commit e antes da resposta de sucesso. Simular falta de permissão/espaço de forma isolada; não encher o disco real. Testar lock ativo, lock abandonado, leitura durante publicação, revisão antiga e ficheiro alterado externamente.

Provas: hashes antes, no ponto de falha e depois da recuperação; IDs e contagens semânticas; erro/estado devolvido; ausência de sucesso/gate enquanto pendente. Leitor deve ver snapshot anterior/completo ou um estado explícito indisponível — nunca mistura aceite. Um lock de grafo não prova exclusão das escritas SU.

## 5. Oráculos de pilotos

Preencher `templates/PILOT_ORACLE.json` antes de avaliar o candidato. A estrutura entregue está vazia por intenção: não foram inventadas regras de negócio dos Excels. O preenchimento é feito em P1 pela inspeção independente da fonte e, quando necessário, confirmação do responsável. Não gerar a referência a partir das conclusões do candidato que será testado.

Cada item: ID, proposição/relação esperada, classe epistemológica, criticidade, locator/hash de fonte, condição de resolução, gate aplicável e notas de revisão. Incluir afirmações proibidas e limitações de extração. O avaliador não recebe apenas a resposta do candidato; abre evidência. Itens incertos ficam marcados para validação, não são usados como “verdade” inventada.

Comparar três dimensões separadas:

1. Extração: regras/relações/Unknowns realmente recuperados e sustentados; omissões e falsas afirmações.
2. Persistência: identidade, histórico e proveniência guardados sem perda.
3. Recuperação: sessão nova utiliza corretamente conhecimento necessário, não apenas consegue listar nós.

Cobertura de itens críticos esperados = 100%; zero falso Confirmed crítico e zero gate indevido. Itens não críticos: registar recuperação e ruído; qualidade não inferior ao baseline sob a mesma rubrica. Não aceitar maior contagem de Findings como melhoria sem relevância. Não inventar precisão estatística a partir de dois pilotos.

Para council opcional: fixar antes a rubrica, inputs, configuração, número de repetições e critério de não inferioridade. Se variabilidade/informação impedem conclusão, manter default atual. P11 não é gate da entrega base.

## 6. Sessões independentes

Guardar inputs imutáveis e hashes; usar engagement novo para cada braço comparável. Encerrar sessão real e reabrir sem mensagens anteriores/resumo manual. Usar apenas mecanismos oficiais do projeto para reconstrução. Registar modelo/configuração, se acessíveis, e campos que não se conseguiram observar.

Sequência completa: Capture/Discovery → resolução → Frame → Options → Premortem/Simulation aplicável → Decide → Blueprint → Render/Deliver. Pedir em cada reinício: fase; factos e pressupostos; Unknowns/Findings/conflitos; decisões; Coverage; bloqueios; próximo passo. Comparar proposições/estados/locators, não igualdade de texto.

Adicionar reinício após erro e após fonte atualizada. Trocar entre dois engagements e verificar que não entra informação do primeiro no segundo. Se não houver execução Claude Code disponível, documentar impedimento e não marcar E01/E02 como concluídos apenas porque processos Python/Node passaram.

## 7. UX, grafo e simplificações

Operador novo deve explicar fase, bloqueio e próximo passo sem abrir schemas ou IDs de grafo. Registar tarefa, tempo observado, dúvidas e resposta; cerca de dois minutos é referência de usabilidade, não substitui correção.

A inspeção do grafo mostra relações completas recuperáveis, ligações a fontes e componentes desconectados reais. Não exigir que tudo seja um único componente nem criar links fictícios. Contexto pode ser parcial; export/traversal de debug permite acesso ao restante.

Para cada remoção P9, preservar a garantia com testes pelos mesmos caminhos de entrada e repetir pilotos afetados. Proteger auditabilidade de council-log, autorizações, revalidação e isolamento. Se nada é redundante, documentar e manter; não cortar funcionalidade para obter número menor de ficheiros.

## 8. Resultado final

`FINAL-VALIDATION.md` inclui baseline e final, IDs de testes alterados, logs, casos, versões/hashes, pilotos, avaliação independente, falhas aceites e respetivo impacto, ambiente suportado, limites medidos, recovery/migração e pacote final. Nenhum campo de template por preencher conta como evidência.
